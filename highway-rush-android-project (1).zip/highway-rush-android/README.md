# Highway Rush 3D — Android APK গাইড

গেমের সোর্স কোড: `www/index.html` (একটাই ফাইল, Three.js r128)।
`three.min.js` ZIP-এ নেই; `npm install` করলে অটো আসে (offline APK-র জন্য দরকার)।

## পদ্ধতি ১: কম্পিউটারে (Android Studio/SDK সহ)
প্রয়োজন: Node.js 18+, JDK 17, Android SDK (Android Studio ইনস্টল করলেই হয়)।

```bash
npm install
npm run android:init      # Android প্রজেক্ট তৈরি + landscape/fullscreen প্যাচ
npm run android:apk       # ডিবাগ APK বানায়
```
APK এখানে পাবে: `android/app/build/outputs/apk/debug/app-debug.apk`
ফোনে কপি করে ইনস্টল করো (Unknown sources চালু করতে হবে)।

Android Studio-তে খুলতে: `npm run android:open`

## পদ্ধতি ২: কম্পিউটার ছাড়াই (GitHub Actions)
1. GitHub-এ নতুন repo বানিয়ে এই ফোল্ডারের সব ফাইল আপলোড করো (`.github` সহ)।
2. Actions ট্যাব → "Build Android APK" → Run workflow।
3. শেষ হলে Artifacts থেকে `highway-rush-debug-apk` ডাউনলোড করো, ভেতরে `app-debug.apk`।

## গেম বদলানোর পর
`www/index.html` এডিট করে `npm run android:sync`, তারপর আবার `npm run android:apk`।

## ব্রাউজারে টেস্ট
`npm run serve` → http://localhost:8080

## Play Store রিলিজ (ঐচ্ছিক)
- `android/` ফোল্ডারে Android Studio → Build → Generate Signed Bundle (AAB)।
- অ্যাপের নাম/আইডি বদলাতে `capacitor.config.json` এডিট করে `android/` মুছে আবার `npm run android:init` চালাও।
- আইকন বদলাতে: `android/app/src/main/res/mipmap-*` ফোল্ডারের `ic_launcher*` ফাইল বদলাও।

## কন্ট্রোল
স্টিয়ারিং হুইল টেনে ঘোরাও, ডানে GAS/BRAKE। 📷 ক্যামেরা, 🌧 বৃষ্টি, ❚❚ মেনু/গাড়ি বদল।
কিবোর্ড: WASD/তীর, C = ক্যামেরা, R = বৃষ্টি।
