// Copies the offline Three.js build into www/ so the APK works without internet.
const fs = require("fs"), path = require("path");
const src = path.join(__dirname, "..", "node_modules", "three", "build", "three.min.js");
const dst = path.join(__dirname, "..", "www", "three.min.js");
if (!fs.existsSync(src)) { console.error("three.min.js not found. Run: npm install"); process.exit(1); }
fs.copyFileSync(src, dst);
console.log("Copied three.min.js ->", dst);
