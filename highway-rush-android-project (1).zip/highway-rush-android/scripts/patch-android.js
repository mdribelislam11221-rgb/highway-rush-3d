// Forces landscape + fullscreen on the generated Android project.
const fs = require("fs"), path = require("path");
const mf = path.join(__dirname, "..", "android", "app", "src", "main", "AndroidManifest.xml");
let x = fs.readFileSync(mf, "utf8");
if (!x.includes("screenOrientation")) {
  x = x.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(mf, x);
}
const st = path.join(__dirname, "..", "android", "app", "src", "main", "res", "values", "styles.xml");
if (fs.existsSync(st)) {
  let s = fs.readFileSync(st, "utf8");
  if (!s.includes("windowFullscreen")) {
    s = s.replace(/(<style name="AppTheme.NoActionBarLaunch"[\s\S]*?<\/style>)/, "$1")
         .replace(/(<style name="AppTheme.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
    fs.writeFileSync(st, s);
  }
}
console.log("Android project patched (landscape, fullscreen).");
